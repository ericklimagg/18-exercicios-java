/******************************************************************************

Questao 11

*******************************************************************************/


public class Main {
    public static void main(String[] args) {
        Pessoa pessoa1 = new Pessoa("Andre", 25);
        pessoa1.exibir();
    }
}


