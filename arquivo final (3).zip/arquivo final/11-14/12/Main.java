/******************************************************************************

Questao 12

*******************************************************************************/


public class Main {
    public static void main(String[] args) {
        Pessoa pessoa1 = new Pessoa("Andre", 25);
        pessoa1.exibir();

        System.out.println("----");

        Aluno aluno1 = new Aluno("Bruna", 21, 12345);
        aluno1.exibir();
    }
}






